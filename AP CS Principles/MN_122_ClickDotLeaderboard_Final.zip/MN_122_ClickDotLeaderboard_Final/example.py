studentName = "Becky"
studentName = studentName[2:3]
print(studentName)